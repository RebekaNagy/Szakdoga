﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P4Checking.Model
{
    public class IdEnvironment
    {
        public string LeafEnv { get; set; }
        public string EnvType { get; set; }
        public List<string> EnvId { get; set; }
    }
}
